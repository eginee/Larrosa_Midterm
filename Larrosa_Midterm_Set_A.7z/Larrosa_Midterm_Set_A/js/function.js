function Generate()
{
    var random = Math.random()*10;
    random = Math.floor (random)+1;

    if (random == 1)
    {document.querySelector("motor").style.background = "darkblue";}
    else if (random == 2) {document.querySelector(".motor").style.background = "black";}
    else if (random == 3) {document.querySelector(".motor").style.background = "orange";}
    else if (random == 4) {document.querySelector(".motor").style.background = "salmon";}
    else if (random == 5) {document.querySelector(".motor").style.background = "green";}
    else if (random == 6) {document.querySelector(".motor").style.background = "red";}
    else if (random == 7) {document.querySelector(".motor").style.background = "darkgoldenrod";}
    else if (random == 8) {document.querySelector(".motor").style.background = "peach";}
    else if (random == 9) {document.querySelector(".motor").style.background = "lightseagreen";}
    else
    {document.querySelector(".motor").style.background = "yellow";}
}

function Show()
{
  var color = document.querySelector(".color").value;
  document.querySelector(".motor").style.backgroundColor = color;

}

function Reset()
{
    document.querySelector(".motor").style.backgroundColor = "white";
}


